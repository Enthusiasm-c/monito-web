import { NextRequest, NextResponse } from 'next/server';
import { enhancedFileProcessor } from '../../../../services/enhancedFileProcessor';
import { prisma } from '../../../../../lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const { uploadId } = await request.json();

    if (!uploadId) {
      return NextResponse.json(
        { error: 'Upload ID is required' },
        { status: 400 }
      );
    }

    // Check if upload exists
    const upload = await prisma.upload.findUnique({
      where: { id: uploadId }
    });

    if (!upload) {
      return NextResponse.json(
        { error: 'Upload not found' },
        { status: 404 }
      );
    }

    // Reset upload status
    await prisma.upload.update({
      where: { id: uploadId },
      data: {
        status: 'pending',
        progressPercentage: 0,
        currentStage: 'waiting',
        errorMessage: null,
        startedAt: new Date(),
        completedAt: null
      }
    });

    // Start reprocessing
    const result = await enhancedFileProcessor.processFile(uploadId);

    return NextResponse.json({
      success: true,
      message: 'Upload reprocessing started',
      result
    });

  } catch (error) {
    console.error('Error reprocessing upload:', error);
    return NextResponse.json(
      { error: 'Failed to reprocess upload' },
      { status: 500 }
    );
  }
}